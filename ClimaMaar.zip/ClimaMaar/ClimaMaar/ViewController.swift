//
//  ViewController.swift
//  ClimaMaar
//
//  Created by macbook on 07/03/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var clima: UISlider!
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var respuesta: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func clima(_ sender: UISlider) {
        var a : Float
        a = clima.value
        view.backgroundColor = UIColor(displayP3Red: 1, green: CGFloat(a/100), blue: 1, alpha: (0.5))
        print(a)
        switch a {
        
        case 1...25:
            respuesta.text = "Lluvioso"
            imagen.image = #imageLiteral(resourceName: "imagenes-cielo-lluvioso3")
            
        case 25...50:
            respuesta.text = "Nublado"
            imagen.image = #imageLiteral(resourceName: "Nublado")
            
        case 50...75:
            respuesta.text = "Despejado"
            imagen.image = #imageLiteral(resourceName: "despejado")
            
        default:
            respuesta.text = "Soleado"
            imagen.image = #imageLiteral(resourceName: "sol")
        }
        
    }
    
    


}

